#! /bin/bash
#SBATCH --partition=ps
#SBATCH --error=%x.stderrn#SBATCH --output=%x.stdout
#SBATCH --mail-type=END,FAIL
#SBATCH --mail-user=andrey.gruzinov@desy.de
source /apps/prod/atsas/atsas-env latest
cd ${SLURM_SUBMIT_DIR}
/software/atsas/3.0.4/bin/lipmix < test_lipmix_MLV_n_dist_1_[1_3_4_5_6_7_9_10]_998
